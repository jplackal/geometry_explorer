
window.startCamera = async function () {
    const video = document.getElementById("cameraVideo");

    try {
        const stream = await navigator.mediaDevices.getUserMedia({
            video: {
                width: 640,
                height: 480
            },
            audio: false
        });

        video.srcObject = stream;
        await video.play();

        document.getElementById("cameraStatus").textContent =
            "Camera connected!";
    } catch (error) {
        document.getElementById("cameraStatus").textContent =
            error.name + ": " + error.message;
    }
};
